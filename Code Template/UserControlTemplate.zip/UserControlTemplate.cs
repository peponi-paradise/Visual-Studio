﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : UserControl
    {
        /*-------------------------------------------
         * 
         *      Design time properties
         * 
         -------------------------------------------*/



        /*-------------------------------------------
         * 
         *      Events
         * 
         -------------------------------------------*/



        /*-------------------------------------------
         * 
         *      Public members
         * 
         -------------------------------------------*/



        /*-------------------------------------------
         * 
         *      Private members
         * 
         -------------------------------------------*/



        /*-------------------------------------------
         * 
         *      Constructor / Destructor
         * 
         -------------------------------------------*/

        public $safeitemname$()
        {
            InitializeComponent();
        }

        /*-------------------------------------------
         * 
         *      Event functions
         * 
         -------------------------------------------*/



        /*-------------------------------------------
         * 
         *      Public functions
         * 
         -------------------------------------------*/



        /*-------------------------------------------
         * 
         *      Private functions
         * 
         -------------------------------------------*/



        /*-------------------------------------------
         * 
         *      Helper functions
         * 
         -------------------------------------------*/
    }
}
